import xbmc
import xbmcaddon
import xbmcgui
import os

ADDON = xbmcaddon.Addon()

dlg = WidgetSetupDialog(
    "DialogWidgetSetup.xml",
    ADDON.getAddonInfo("path"),
    ""
)

)

class WidgetSetupDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        xbmc.log("[WidgetSetup] Dialog onInit", xbmc.LOGINFO)

    def onClick(self, controlId):
        xbmc.log(f"[WidgetSetup] Click {controlId}", xbmc.LOGINFO)
        self.close()

def main():
    xbmc.sleep(3000)
    xbmc.log("[WidgetSetup] Opening WindowXMLDialog", xbmc.LOGINFO)

    dlg = WidgetSetupDialog(
        "DialogWidgetSetup.xml",
        BASE_PATH,
        ""
    )
    dlg.doModal()
    del dlg

    xbmc.log("[WidgetSetup] Dialog closed", xbmc.LOGINFO)

if __name__ == "__main__":
    main()
